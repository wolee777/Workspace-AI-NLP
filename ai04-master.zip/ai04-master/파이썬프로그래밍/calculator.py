def add(a,b):
    c = a + b
    return c

def subtract(a,b):
    c = a - b
    return c

def multiply(a,b):
    c = a * b
    return c

def divide(a,b):
    c = a / b
    return c

# print('나는 모듈입니다')

if __name__ == '__main__':
    print(add(10,20))
    print(subtract(30,10))





