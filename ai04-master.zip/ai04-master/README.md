# AI 기본과정

강사: 고병화

E-mail : digicope@aicore.co.kr


git 주소 :    https://github.com/digicope/ai04

(사용기간 : 2020.04.13  ~ 2020.05.15)


### - GitHub의 쥬피터 노트북 파일 다운로드 방법
https://datascience.stackexchange.com/questions/35555/how-to-download-a-jupyter-notebook-from-github

#### git에서 노트북 파일을 클릭하고 --> Raw 버튼 클릭  --> Ctrl + S 로 저장  --> 저장시 확장자 .txt를 없애준다 --> 주피터노트북에서 읽어온다


#### 쥬피터 노트북 단축키 요약
https://kkokkilkon.tistory.com/151


#### ------------------------------------------------------------------------------------------------------------------------

##### [필독] 강의 중 깃허브에서 공유되는 자료는 출판이나 인터넷 공유사이트에서의 무단 게재 시 저작권 문제가 될수 있아오니
#####        학습을 위한 개인적 용도로만 사용해주시길 부탁드립니다~       
